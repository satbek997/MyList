package vehicles;

public class CheryEngine implements Engine {
    @Override
    public void start() {
        System.out.println("Chery engine started");
    }
}
