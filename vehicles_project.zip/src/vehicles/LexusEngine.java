package vehicles;

public class LexusEngine implements Engine {
    @Override
    public void start() {
        System.out.println("Lexus engine started");
    }
}
