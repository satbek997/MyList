package vehicles;

public class Chery implements Car {
    @Override
    public void drive() {
        System.out.println("Chery is driving");
    }
}
