package vehicles;

public interface Car {
    void drive();
}
