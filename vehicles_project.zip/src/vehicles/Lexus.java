package vehicles;

public class Lexus implements Car {
    @Override
    public void drive() {
        System.out.println("Lexus is driving");
    }
}
