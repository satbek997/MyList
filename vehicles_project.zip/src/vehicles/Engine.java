package vehicles;

public interface Engine {
    void start();
}
